import './App.css'
import { Routes, Route } from 'react-router-dom'
import { useState, useEffect } from 'react'
import Navigation from './components/Navigation'
import Home from './pages/Home'
import AddBook from './pages/AddBook'
import EditBook from './pages/EditBook'
import ViewBook from './pages/ViewBook'
import BookDetail from './pages/bookDetail'

function App() {

  const [books, setBooks] = useState(() => {
    const savedBooks = localStorage.getItem("Books");

    if (savedBooks) {
      return JSON.parse(savedBooks);
    } else {
      return [
        {
          b_id: 101,
          title: "Dharmayoddha Kalki",
          type: " History",
          author: "Kevin Missal",
          price: 1000,
          publisher: "Prakash Books",
          imageUrl:
            "https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcRCi-rEXmNB2uPxm770AHqvkYUPYnmK9p7IR6rcviM2u_Q84ArKafjLyZg24-wOx06L5Qte0Mih9_KQ1AvJxfHuVRGBPXQBl4s7dG6iOwpVxEQOcvaBclGlJQ",
          description:
            "an action-packed mythological fiction series following Kalki Hari, a young man from Shambala who discovers he is the final avatar of Lord Vishnu"
        }
      ];
    }
  });

  const handleAddBook = (book) => {
    setBooks((prevBooks) => [...prevBooks, book]);
  };

  const handleDeleteBook = (id) => {
    setBooks(books.filter(book => book.b_id !== id));
  };

  const handleUpdateBook = (updatedBook) => {
    setBooks(
      books.map((book) =>
        book.b_id === updatedBook.b_id ? updatedBook : book
      )
    );
  };

  useEffect(() => {
    localStorage.setItem("Books", JSON.stringify(books));
  }, [books]);

  return (
    <>
      <Navigation />

      <Routes>
        <Route path="/" element={<Home books={books} />} />

        <Route
          path="/add"
          element={<AddBook addBook={handleAddBook} books={books} />}
        />

        <Route path="/view/:id" element={<BookDetail books={books} />} />

        <Route
          path="/viewBook"
          element={<ViewBook books={books} deleteBook={handleDeleteBook} />}
        />

        <Route
          path="/editBook/:id"
          element={<EditBook books={books} updateBook={handleUpdateBook} />}
        />
      </Routes>
    </>
  )
}

export default App