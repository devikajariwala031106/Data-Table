import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';

function Navigation() {
    return (
        <Navbar expand="lg" className="bg-primary shadow">
            <Container fluid>
                <Navbar.Brand>
                    <Link to="/">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlGig5hPC-t5SR7F7sM_K2qhEBkheDQHR8rQ&s"
                            className='logo'
                            alt="book logo" />
                    </Link>
                </Navbar.Brand>

                <Navbar.Collapse>
                    <Nav className="ms-auto">
                        <Link to="/" className="nav-link text-white">Home</Link>
                        <Link to="/add" className="nav-link text-white">Add Book</Link>
                        <Link to="/viewBook" className="nav-link text-white">View Book</Link>
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    )
}
export default Navigation;