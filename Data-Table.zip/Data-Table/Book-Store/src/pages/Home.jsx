import { Link } from "react-router-dom";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Card from 'react-bootstrap/Card';

function Home({ books }) {
    return (
        <>
            <h2 className="mt-5 text-center fw-bold text-primary">
                Books Available In Store
            </h2>

            <Container className="mt-5">
                <Row>
                    {books?.map((book) => (
                        <Col key={book.b_id} md={3} className="mb-4">
                            <Card className="shadow-lg border-0 h-100">
                                <Card.Img variant="top" src={book.imageUrl} />
                                <Card.Body>
                                    <Card.Title>{book.title}</Card.Title>
                                    <Card.Text className="card-text">
                                        {book.description}
                                    </Card.Text>
                                    <Link to={`/view/${book.b_id}`} className='btn btn-primary'>
                                        View Details
                                    </Link>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            </Container>
        </>
    )
}
export default Home;